class NotAuthorized(Exception):
    pass


class MissingToken(Exception):
    pass