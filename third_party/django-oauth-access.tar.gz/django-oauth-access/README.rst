django-oauth-access README
==========================

This app provides support for:

 * Twitter
 * LinkedIn
 * Yahoo
 * Facebook (using OAuth 2.0 — it is functional, but needs more work)
 * Likely any OAuth 1.0a compliant site
