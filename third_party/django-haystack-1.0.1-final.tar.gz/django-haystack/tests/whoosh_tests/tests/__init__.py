import warnings
warnings.simplefilter('ignore', Warning)

from whoosh_tests.tests.whoosh_query import *
from whoosh_tests.tests.whoosh_backend import *
