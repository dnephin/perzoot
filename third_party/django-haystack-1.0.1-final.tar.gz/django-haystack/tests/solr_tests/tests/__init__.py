import warnings
warnings.simplefilter('ignore', Warning)

from solr_tests.tests.solr_query import *
from solr_tests.tests.solr_backend import *
from solr_tests.tests.templatetags import *
